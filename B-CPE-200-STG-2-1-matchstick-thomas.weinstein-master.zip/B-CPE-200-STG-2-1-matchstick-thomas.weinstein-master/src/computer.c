/*
** EPITECH PROJECT, 2021
** matchstick-master
** File description:
** my_bot
*/

#include "matchstick.h"

void comput_play(struct get *get)
{
    const char *play = "AI's turn...\n";
    const char *defait = "I lost... snif... but I'll get you next time!!\n";
    const char *win = "You lost, too bad...\n";

    if (real_number(get) == 0) {
        my_putstr(win);
        get->quit = 2;
        return;
    }
    my_putstr(play);
    randoo(get);
    if (real_number(get) == 0) {
        affich(get);
        my_putstr(defait);
        get->quit = 1;
        return;
    }
}

void randoo(struct get *get)
{
    int number = 0;
    int i = calc(0, get->size - 1);

    for (int len; (len = real_number_line(get, i)) != -1; ) {
        if (len == 0) {
            i = calc(0, get->size);
            continue;
        }
        if (len == 1 || (real_number(get) == 2 && len == 2))
            number = 1;
        else if (len > get->exces && get->exces - 1 != 1)
            number = calc(1, get->exces - 1);
        else
            number = len - 1;
        if (len == get->exces + 1)
            number = get->exces;
        remo_match(get, i, number);
        writes(number, i);
        break;
    }
}

void writes(int nbr, int i)
{
    const char *deb = "AI removed ";
    const char *mi = " match(es) from line ";

    my_putstr(deb);
    my_put_nbr(nbr, 1);
    my_putstr(mi);
    my_put_nbr(i + 1, 1);
    my_putchar('\n', 1);
}

void remo_match(struct get *get, int line, int match)
{
    int i = my_strlen(get->c[0]) - 1;

    for (; i >= 0 && match != 0; i--) {
        if (get->c[line][i] == '|') {
            get->c[line][i] = ' ';
            match--;
        }
    }
}