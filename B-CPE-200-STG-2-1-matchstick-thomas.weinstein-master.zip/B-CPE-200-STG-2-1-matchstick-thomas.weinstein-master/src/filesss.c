/*
** EPITECH PROJECT, 2021
** matchstick-master
** File description:
** my_reader
*/

#include "matchstick.h"

char *keep_mem(char *src, int position)
{
    char *c = malloc(sizeof(char) * (position + 1));
    int i = 0;

    if (c == NULL)
        return (NULL);
    for (i = 0; position >= 0; i++) {
        if (src[i])
            c[i] = src[i];
        position--;
    }
    return (c);
}

int get_pos(int fd, char *buffer, char *c, int n)
{
    static int position = READ_SIZE;
    static int i = 0;

    if (i >= position || i == 0) {
        i = 0;
        if ((position = read(fd, buffer, READ_SIZE)) < 0 || fd < 0 || fd > 256)
            return (-2);
    }
    if (position == 0) {
        c[n] = '\0';
        i = -1;
    }
    if (position != 0 && buffer[i] == '\n')
        c[n] = '\0';
    if (position != 0 && buffer[i] != '\n')
        c[n] = buffer[i];
    i++;
    return (position);
}

char *stat_doc(char *c, int i)
{
    if (i % READ_SIZE == 0)
        return (keep_mem(c, i + READ_SIZE + 1));
    else
        return (c);
}

char *get_next_line(int fd)
{
    static char buffer[READ_SIZE];
    char *c = malloc((READ_SIZE + 1) * sizeof(char));
    int i = 0;
    int pos;

    if (c == NULL || fd < 0 || fd > 256 ||
        READ_SIZE < 0 || read(fd, buffer, 0) < 0)
        return (NULL);
    pos = get_pos(fd, buffer, c, i);
    while (c[i] != '\0' && i < READ_SIZE + 1) {
        c = stat_doc(c, i);
        if (!c || c == NULL)
            return (NULL);
        pos = get_pos(fd, buffer, c, ++i);
        if (pos == -2)
            return (NULL);
    }
    c[i] = '\0';
    return (c);
}