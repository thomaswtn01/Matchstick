/*
** EPITECH PROJECT, 2021
** matchstick-master
** File description:
** main
*/

#include "matchstick.h"

int main(int ac, char **av)
{
    const int qui = 84;
    const int false = 0;
    struct get *get;

    srand(time(NULL));
    if (check(ac, av) == false)
        return (qui);
    get = response(av);
    if (get == NULL)
        return (qui);
    charge(get);
    return (get->quit);
}

int check(int ac, char **av)
{
    const int yes = 1;
    const int no = 0;
    int size;
    int exces;

    if (ac != 3)
        return (no);
    size = my_getnbr(av[1]);
    exces = my_getnbr(av[2]);
    if (size < 1 || size > 100 || exces <= 0)
        return (no);
    return (yes);
}

struct get *response(char **str)
{
    struct get *get = malloc(sizeof(struct get));

    if (get == NULL)
        return (NULL);
    get->size = my_getnbr(str[1]);
    get->exces = my_getnbr(str[2]);
    get->c = malloc(sizeof(char *) * get->size);
    get->quit = 0;
    if (get->c == NULL)
        return (NULL);
    for (int i = 0; i < get->size; i++) {
        get->c[i] = malloc(sizeof(char) *
            (1 + (2 * (get->size))));
        if (get->c[i] == NULL)
            return (NULL);
    }
    return (get);
}

int in_game(struct get *get, int line)
{
    char *str;
    int i;

    my_putstr("Matches: ");
    str = get_next_line(0);
    if (str == NULL) {
        get->quit = 0;
        return (84);
    }
    i = my_getnbr(str);
    if (inmatch_err(get, i) == 0)
        return (before(get, 1));
    return (supp(get, line, i));
}