/*
** EPITECH PROJECT, 2021
** matchstick-master
** File description:
** my_utils
*/

#include "matchstick.h"

int real_number(struct get *get)
{
    int len = 0;

    for (int i = 0; i < get->size; i++)
        for (int j = 0; get->c[i][j]; j++)
            if (get->c[i][j] == '|')
                len++;
    return (len);
}

int real_number_line(struct get *get, int line)
{
    const char *err = "Error: this line is out of range\n";
    int len = 0;

    if (line >= get->size) {
        my_putstr(err);
        return (-1);
    }
    for (int i = 0; get->c[line][i]; i++)
        if (get->c[line][i] == '|')
            len++;
    return (len);
}

int calc(int a, int b)
{
    return (rand() % (b - a) + a);
}

void my_strcat(char *dest, char *src)
{
    int	i;
    int	j;

    i = 0;
    j = 0;
    while (dest[i])
    {
        i++;
    }
    while (src[j])
    {
        dest[i] = src[j];
        i++;
        j++;
    }
    dest[i] = 0;
}