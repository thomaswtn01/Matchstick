/*
** EPITECH PROJECT, 2021
** matchstick-master
** File description:
** my_engine
*/

#include "matchstick.h"

void charge(struct get *get)
{
    int turn = 0;
    int final;

    draw_map(get);
    affich(get);
    while (real_number(get) != 0 && get->quit == 0 && turn < 900) {
        final = before(get, 0);
        if (final == 0)
            continue;
        else if (final == 84)
            return;
        affich(get);
        comput_play(get);
        if (get->quit != 0)
            break;
        affich(get);
        turn++;
    }
}

int before(struct get *get, int line)
{
    char *str;

    if (line == 0)
        my_putstr("Your turn:\n");
    my_putstr("Line: ");
    str = get_next_line(0);
    if (str == NULL) {
        get->quit = 0;
        return (84);
    }
    line = my_getnbr(str);
    if (line_err(line) == 0)
        return (before(get, 1));
    line--;
    if (real_number_line(get, line) == -1)
        return (before(get, 1));
    return (in_game(get, line));
}

int supp(struct get *get, int line, int match)
{
    const char *err = "Error: not enough matches on this line\n";

    if (real_number_line(get, line) >= 0 &&
        match <= real_number_line(get, line)) {
        removes(get, match, line);
        return (1);
    } else {
        my_putstr(err);
        return (0);
    }
}

void removes(struct get *get, int match, int line)
{
    const char *rm_1 = "Player removed ";
    const char *rm_2 = " match(es) from line ";
    int i = my_strlen(get->c[0]) - 1;

    my_putstr(rm_1);
    my_put_nbr(match, 1);
    for (; i >= 0 && match != 0; i--) {
        if (get->c[line][i] == '|') {
            get->c[line][i] = ' ';
            match--;
        }
    }
    my_putstr(rm_2);
    my_put_nbr(line + 1, 1);
    my_putchar('\n', 1);
}

void affich(struct get *get)
{
    for (int i = 0; i < my_strlen(get->c[0]) + 2; i++)
        my_putchar('*', 1);
    my_putchar('\n', 1);
    for (int i = 0; i < get->size; i++) {
        my_putchar('*', 1);
        my_putstr(get->c[i]);
        my_putchar('*', 1);
        my_putchar('\n', 1);
    }
    for (int i = 0; i < my_strlen(get->c[0]) + 2; i++)
        my_putchar('*', 1);
    my_putchar('\n', 1);
    my_putchar('\n', 1);
}