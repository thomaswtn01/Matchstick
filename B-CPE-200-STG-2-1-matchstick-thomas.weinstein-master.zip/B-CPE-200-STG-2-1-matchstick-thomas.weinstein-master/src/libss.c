/*
** EPITECH PROJECT, 2021
** matchstick-master
** File description:
** my_put
*/

#include "matchstick.h"

void my_putchar(char c, int output)
{
    write(output, &c, 1);
}

void my_putstr(const char *str)
{
    int length = 0;

    while (str[length] != '\0') {
        my_putchar(str[length], 1);
        length++;
    }
}

int my_put_nbr(int nb, int output)
{
    if (nb > 9)
        my_put_nbr(nb / 10, output);
    else if (nb < 0) {
        nb = nb * -1;
        write(output, "-", 1);
        my_put_nbr(nb / 10, output);
    }
    my_putchar((nb % 10 + '0'), output);
    return (0);
}

int my_strlen(const char *str)
{
    int len;

    for (len = 0; str[len]; len++);
    return (len);
}

int my_getnbr(char *str)
{
    int val = 0;

    while (*str) {
        if (*str >= '0' && *str <= '9') {
            val *= 10;
            val += *str - '0';
        }
        else
            return (-1);
        str++;
    }
    return (val);
}