/*
** EPITECH PROJECT, 2021
** matchstick-master
** File description:
** my_map
*/

#include "matchstick.h"

void draw_map(struct get *get)
{
    int i;
    int y;

    for (y = 0; y < get->size; y++) {
        for (i = 0; i < (2 * (get->size)); i++) {
            if (i <= get->size - 2 - y ||
            i >= (2 * (get->size)) - get->size + 1 + y - 1) {
                get->c[y][i] = ' ';
            } else {
                get->c[y][i] = '|';
            }
        }
        get->c[y][i - 1] = '\0';
    }
}

int inmatch_err(struct get *get, int game)
{
    const char *invalid = "Error: invalid input "
        "(positive number expected)\n";
    const char *remove_one = "Error: you have to remove at least one "
        "match\n";
    const char *err = "Error: you cannot remove more than ";
    const char *end = " matches per turn\n";

    if (game == 0) {
        my_putstr(remove_one);
        return (0);
    }
    if (game > get->exces) {
        my_putstr(err);
        my_put_nbr(get->exces, 1);
        my_putstr(end);
        return (0);
    } else if (game == -1) {
        my_putstr(invalid);
        return (84);
    }
    return (1);
}

int line_err(int line)
{
    const char *more = "Error: this line is out of range\n";
    const char *number = "Error: invalid input (positive number "
        "expected)\n";

    if (line == 0) {
        my_putstr(more);
        return (0);
    }
    if (line == -1) {
        my_putstr(number);
        return (0);
    }
    return (1);
}