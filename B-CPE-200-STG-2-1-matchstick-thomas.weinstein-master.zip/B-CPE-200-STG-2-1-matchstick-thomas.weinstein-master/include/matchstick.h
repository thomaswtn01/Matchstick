/*
** EPITECH PROJECT, 2021
** matchstick-master
** File description:
** matchstick
*/

#ifndef  READ_SIZE
#define  READ_SIZE (2048)
#endif  /* !READ_SIZE  */

#ifndef matchstick_
#define matchstick_

    #include <unistd.h>
    #include <stdio.h>
    #include <stdlib.h>
    #include <string.h>
    #include <fcntl.h>
    #include <time.h>

struct get {
    char **c;
    int exces;
    int size;
    int quit;
};

int check(int ac, char **av);
void comput_play(struct get *req);
void writes(int nbr, int i);
void remo_match(struct get *req, int line, int match);
void randoo(struct get *get);
void charge(struct get *get);
int before(struct get *get, int line);
int supp(struct get *get, int line, int match);
void removes(struct get *get, int match, int line);
void affich(struct get *get);
int inmatch_err(struct get *req, int game);
int line_err(int line);
struct get *response(char **str);
int my_getnbr(char *str);
int in_game(struct get *get, int line);
void draw_map(struct get *get);
void my_putchar(char c, int output);
void my_putstr(const char *str);
int my_put_nbr(int nb, int output);
char *keep_mem(char *src, int position);
int get_pos(int fd, char *buffer, char *c, int i);
char *stat_doc(char *c, int i);
char *get_next_line(int fd);
int my_strlen(const char *str);
int real_number(struct get *req);
int real_number_line(struct get *req, int line);
int calc(int a, int b);

#endif